//
//  MyProtocol.h
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyProtocol <NSObject>

-(void) clearText: (NSString*) str;

@end
