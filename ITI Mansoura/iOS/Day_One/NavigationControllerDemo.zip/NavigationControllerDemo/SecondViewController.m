//
//  SecondViewController.m
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [_secondLabel setText:_str];
    
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneMethod)];
    
    
    [self.navigationItem setRightBarButtonItem:rightButton];
    
    
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) doneMethod{
    
    [_myDelegate clearText:@"Hello"];
    [self.navigationController popViewControllerAnimated:YES];
    printf("Hello right Button\n");
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
