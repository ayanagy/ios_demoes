//
//  ViewController.m
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
  //  [self setTitle:@"FirstView"];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)clearText:(NSString *)str{
    
    
    [_myTextFiled setText:str];
    
}


- (IBAction)nextView:(id)sender {
    
    SecondViewController *second = [self.storyboard instantiateViewControllerWithIdentifier:@"secondVC"];
    
    [second setMyDelegate:self];
    [second setStr:@"Hello"];
    
    
    
    [self.navigationController pushViewController:second animated:YES];
    
    
    
}
@end
