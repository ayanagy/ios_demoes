//
//  ViewController.h
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondViewController.h"
#import "MyProtocol.h"

@interface ViewController : UIViewController <MyProtocol>


@property (weak, nonatomic) IBOutlet UITextField *myTextFiled;

- (IBAction)nextView:(id)sender;

@end

