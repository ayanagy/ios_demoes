//
//  AppDelegate.h
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

