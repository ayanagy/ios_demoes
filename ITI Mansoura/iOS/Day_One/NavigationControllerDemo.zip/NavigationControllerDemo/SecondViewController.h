//
//  SecondViewController.h
//  NavigationControllerDemo
//
//  Created by Mohamed Said on 1/1/17.
//  Copyright © 2017 ITI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProtocol.h"

@interface SecondViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *secondLabel;

@property NSString *str;

@property id<MyProtocol> myDelegate;


@end
