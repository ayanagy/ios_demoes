//
//  TestSQLiteTests.h
//  TestSQLiteTests
//
//  Created by JETS on 3/7/14.
//  Copyright (c) 2014 JETS. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TestSQLiteTests : SenTestCase

@end
