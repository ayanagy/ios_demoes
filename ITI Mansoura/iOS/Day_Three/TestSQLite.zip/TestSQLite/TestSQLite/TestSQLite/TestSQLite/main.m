//
//  main.m
//  TestSQLite
//
//  Created by JETS on 3/7/14.
//  Copyright (c) 2014 JETS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JETSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JETSAppDelegate class]));
    }
}
